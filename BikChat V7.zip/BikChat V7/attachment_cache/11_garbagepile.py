# core of the code

hardcodegalore = 1
import time

# definitions

def startup():
    print("Input the amount of GARBAGEPOINTS you want to add to the PILE. The MORE the BETTER.")

def prompt():
    garbaddition = 0
    garbaddition = int(input("How much garbage do you want to add?: "))
    answer = garbaddition
    print(f"You have: {answer} Garbage.")


# loop and boot

startup()
while hardcodegalore == 1:
    prompt()
    time.sleep(2)
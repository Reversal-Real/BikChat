BikChat
Hello, this is BikChat, welcome to the readme.

This was developed and made by @reversalreal on Discord, you should know him lol. Anyways, if you need any help, contact me.

REQUIREMENTS
- Python 3.14 — as far as I know, older versions are probably supported, but are untested.
- PIL/Pillow — run pip install pillow inside of Command Prompt.
- The necessary assets and sounds — sounds aren't REQUIRED, but it'll be weird if you don't have them.
- Being connected to the Radmin VPN server.
- The server being online - it’s run by Reversal/me.

MODDING
This is TECHNICALLY* moddable software!
(* just know what you're doing)
If you want to make your own assets, keep the same filename and drop them into the assets folder. Make SURE they're the same size as the original asset, or things MAY get messed up, i dunno, if you are making custom assets just remember to keep the originals as backups

The same applies to sounds, but sounds are less strict. Just make sure they're .wav files.

If you’re changing anything inside of the code, please keep a backup of the original, any changes that send things to the server WILL probably break something so I wouldn’t recommend it.

Have fun with it!!! :D



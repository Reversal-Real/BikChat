import socket
import threading
import time
import winsound
import tkinter as tk
from tkinter import scrolledtext, filedialog, simpledialog
from datetime import datetime
from PIL import Image, ImageTk
import ctypes
import random
import json
import webbrowser
import re
import struct
import mimetypes
import math
import os

os.system("title BikChat")

HOST = "26.186.103.210"
PORT = 5000

RETRY_DELAY = 3

PACKET_HEADER_SIZE = 4
FILE_CHUNK_SIZE = 64 * 1024

user_count = 0
running = True

announcements_mode = True
announcements_buffer = ""

online_users = []

BASE_DIR = os.path.dirname(
    os.path.abspath(__file__)
)

ASSETS_DIR = os.path.join(
    BASE_DIR,
    "assets"
)

EMOJIS_DIR = os.path.join(
    BASE_DIR,
    "emojis"
)

ATTACHMENT_CACHE_DIR = os.path.join(
    BASE_DIR,
    "attachment_cache"
)

BIKKING_ASSETS_DIR = os.path.join(
    ASSETS_DIR,
    "BikkingAssets"
)

BIKKING_BIK_PATH = os.path.join(
    ASSETS_DIR,
    "bikking_bik.png"
)

BIKKING_SKY_PATH = os.path.join(
    ASSETS_DIR,
    "bikking_sky.png"
)

BIKKING_WATER_PATH = os.path.join(
    ASSETS_DIR,
    "bikking_water.png"
)

SETTINGS_FILE = os.path.join(
    BASE_DIR,
    "settings.json"
)

USERNAME_FILE = os.path.join(
    BASE_DIR,
    "username.txt"
)

BIKCOIN_FILE = os.path.join(
    BASE_DIR,
    "bikcoin.json"
)

BG = "#181818"
CHAT_BG = "#101010"
INPUT_BG = "#242424"
TEXT = "#eeeeee"
SYSTEM_TEXT = "#888888"


root = tk.Tk()

root.overrideredirect(True)

root.geometry(
    "700x550"
)

root.configure(
    bg=BG
)


def get_console_window():

    try:

        return ctypes.windll.kernel32.GetConsoleWindow()

    except Exception:
        return 0


def minimize_console():

    try:

        console_hwnd = get_console_window()

        if console_hwnd:

            ctypes.windll.user32.ShowWindow(
                console_hwnd,
                6
            )

    except Exception:
        pass


def bring_bikchat_to_front():

    try:

        hwnd = root.winfo_id()

        ctypes.windll.user32.ShowWindow(
            hwnd,
            9
        )

        root.lift()

        if always_on_top:

            root.attributes(
                "-topmost",
                True
            )

        else:

            root.attributes(
                "-topmost",
                True
            )

            root.after(
                50,
                lambda:
                root.attributes(
                    "-topmost",
                    False
                )
            )

        ctypes.windll.user32.SetForegroundWindow(
            hwnd
        )

    except Exception:
        pass


console_was_foreground = False


def check_console_focus():

    global console_was_foreground

    if not running:
        return

    try:

        console_hwnd = get_console_window()

        if console_hwnd:

            foreground_hwnd = (
                ctypes.windll.user32.GetForegroundWindow()
            )

            is_foreground = (
                foreground_hwnd == console_hwnd
            )

            if is_foreground and not console_was_foreground:

                console_was_foreground = True

                bring_bikchat_to_front()

                root.after(
                    25,
                    minimize_console
                )

            elif not is_foreground:

                console_was_foreground = False

    except Exception:
        pass

    root.after(
        100,
        check_console_focus
    )


muted = False


def load_settings():

    try:

        with open(
            SETTINGS_FILE,
            "r"
        ) as file:

            settings = json.load(
                file
            )

        return settings.get(
            "muted",
            False
        )

    except Exception:

        return False


def save_settings():

    with open(
        SETTINGS_FILE,
        "w"
    ) as file:

        json.dump(
            {
                "muted": muted
            },
            file,
            indent=4
        )


def load_bikcoin():

    try:

        with open(
            BIKCOIN_FILE,
            "r",
            encoding="utf-8"
        ) as file:

            data = json.load(
                file
            )

        value = data.get(
            "bikcoin",
            0
        )

        if isinstance(
            value,
            bool
        ):

            return 0

        value = int(
            value
        )

        if value < 0:

            return 0

        return value

    except Exception:

        return 0


def save_bikcoin():

    try:

        with open(
            BIKCOIN_FILE,
            "w",
            encoding="utf-8"
        ) as file:

            json.dump(
                {
                    "bikcoin": bikcoin
                },
                file,
                indent=4
            )

    except Exception:
        pass


bikcoin = load_bikcoin()


def format_bikcoin(value):

    try:

        value = int(
            value
        )

    except Exception:

        return "0"

    if value < 1000:

        return f"{value:,}"

    suffixes = (
        "K",
        "M",
        "B",
        "T",
        "Qa",
        "Qi",
        "Sx",
        "Sp",
        "Oc",
        "No",
        "Dc"
    )

    number = float(
        value
    )

    for suffix in suffixes:

        number /= 1000

        if abs(number) < 1000:

            if number >= 100:

                formatted = f"{number:.0f}"

            elif number >= 10:

                formatted = f"{number:.1f}"

            else:

                formatted = f"{number:.2f}"

            formatted = formatted.rstrip(
                "0"
            ).rstrip(
                "."
            )

            return f"{formatted}{suffix}"

    return f"{value:.3e}"


def update_bikcoin_display():

    if "bikcoin_label" in globals():

        bikcoin_label.configure(
            text=f"BikCoin: {format_bikcoin(bikcoin)}"
        )


def bikcoin_tick():

    global bikcoin

    if not running:
        return

    bikcoin += 1

    save_bikcoin()

    update_bikcoin_display()

    if client is not None:

        try:

            send_packet(
                client,
                {
                    "type": "bikcoin_update",
                    "bikcoin": bikcoin
                }
            )

        except OSError:
            pass

    root.after(
        60000,
        bikcoin_tick
    )


def play_sound(path):

    if muted:
        return

    try:

        winsound.PlaySound(
            path,
            winsound.SND_FILENAME |
            winsound.SND_ASYNC
        )

    except Exception:
        pass


def toggle_sound():

    global muted

    muted = not muted

    if muted:

        sound_button.config(
            image=sound_off_img
        )

    else:

        sound_button.config(
            image=sound_on_img
        )

    save_settings()


muted = load_settings()

play_sound(
    os.path.join(
        BASE_DIR,
        "sounds",
        "startup.wav"
    )
)

titlebar_image = ImageTk.PhotoImage(
    Image.open(
        os.path.join(
            ASSETS_DIR,
            "titlebar.png"
        )
    )
)

close_img = ImageTk.PhotoImage(
    Image.open(
        os.path.join(
            ASSETS_DIR,
            "close.png"
        )
    )
)

lock_off_img = ImageTk.PhotoImage(
    Image.open(
        os.path.join(
            ASSETS_DIR,
            "lock_off.png"
        )
    )
)

lock_on_img = ImageTk.PhotoImage(
    Image.open(
        os.path.join(
            ASSETS_DIR,
            "lock_on.png"
        )
    )
)

send_img = ImageTk.PhotoImage(
    Image.open(
        os.path.join(
            ASSETS_DIR,
            "send.png"
        )
    )
)

add_img = ImageTk.PhotoImage(
    Image.open(
        os.path.join(
            ASSETS_DIR,
            "add.png"
        )
    )
)

sound_on_img = ImageTk.PhotoImage(
    Image.open(
        os.path.join(
            ASSETS_DIR,
            "sound_on.png"
        )
    )
)

sound_off_img = ImageTk.PhotoImage(
    Image.open(
        os.path.join(
            ASSETS_DIR,
            "sound_off.png"
        )
    )
)


def load_tab_icon(filename):

    image = Image.open(
        os.path.join(
            ASSETS_DIR,
            filename
        )
    ).convert(
        "RGBA"
    )

    image = image.resize(
        (32, 32),
        Image.Resampling.LANCZOS
    )

    return ImageTk.PhotoImage(
        image
    )


chat_tab_img = load_tab_icon(
    "chat.png"
)

announcements_tab_img = load_tab_icon(
    "announcements.png"
)

users_locked_tab_img = load_tab_icon(
    "users_locked.png"
)

try:

    bikking_tab_img = load_tab_icon(
        "bikking.png"
    )

except Exception:

    bikking_tab_img = None


titlebar = tk.Frame(
    root,
    width=700,
    height=40,
    bg=BG,
    borderwidth=0,
    highlightthickness=0,
    padx=0,
    pady=0
)

titlebar.pack(
    side="top",
    fill="x"
)

titlebar.pack_propagate(False)

titlebar_label = tk.Label(
    titlebar,
    image=titlebar_image,
    bg=BG,
    borderwidth=0,
    highlightthickness=0,
    padx=0,
    pady=0
)

titlebar_label.place(
    x=0,
    y=0,
    width=700,
    height=40
)

drag_x = 0
drag_y = 0


def start_drag(event):

    global drag_x
    global drag_y

    drag_x = event.x
    drag_y = event.y


def drag_window(event):

    x = (
        root.winfo_x()
        + event.x
        - drag_x
    )

    y = (
        root.winfo_y()
        + event.y
        - drag_y
    )

    root.geometry(
        f"700x550+{x}+{y}"
    )


titlebar_label.bind(
    "<Button-1>",
    start_drag
)

titlebar_label.bind(
    "<B1-Motion>",
    drag_window
)


def close_window():

    global running

    running = False

    save_bikcoin()

    root.destroy()


close_button = tk.Button(
    titlebar,
    image=close_img,
    bg=BG,
    activebackground=BG,
    borderwidth=0,
    highlightthickness=0,
    relief="flat",
    command=close_window
)

close_button.place(
    relx=1.0,
    x=-38,
    y=1,
    width=38,
    height=38
)

always_on_top = False


def toggle_always_on_top():

    global always_on_top

    always_on_top = not always_on_top

    root.attributes(
        "-topmost",
        always_on_top
    )

    if always_on_top:

        lock_button.config(
            image=lock_on_img
        )

    else:

        lock_button.config(
            image=lock_off_img
        )


lock_button = tk.Button(
    titlebar,
    image=lock_off_img,
    bg=BG,
    activebackground=BG,
    borderwidth=0,
    highlightthickness=0,
    relief="flat",
    command=toggle_always_on_top
)

lock_button.place(
    relx=1.0,
    x=-76,
    y=1,
    width=38,
    height=38
)

sound_button = tk.Button(
    titlebar,
    image=sound_off_img if muted else sound_on_img,
    bg=BG,
    activebackground=BG,
    borderwidth=0,
    highlightthickness=0,
    relief="flat",
    command=toggle_sound
)

sound_button.place(
    relx=1.0,
    x=-114,
    y=0,
    width=38,
    height=40
)

bikcoin_label = tk.Label(
    titlebar,
    text=f"BikCoin: {format_bikcoin(bikcoin)}",
    bg="#800000",
    fg="#FFFFFF",
    font=("Segoe UI", 9),
    anchor="center"
)

bikcoin_label.place(
    x=295,
    y=8,
    width=110,
    height=24
)

current_tab = "chat"

content_frame = tk.Frame(
    root,
    bg=BG,
    borderwidth=0,
    highlightthickness=0
)

content_frame.pack(
    fill="both",
    expand=True
)

chat_page = tk.Frame(
    content_frame,
    bg=BG,
    borderwidth=0,
    highlightthickness=0
)

announcements_page = tk.Frame(
    content_frame,
    bg=BG,
    borderwidth=0,
    highlightthickness=0
)

users_page = tk.Frame(
    content_frame,
    bg=BG,
    borderwidth=0,
    highlightthickness=0
)

bikking_page = tk.Frame(
    content_frame,
    bg=BG,
    borderwidth=0,
    highlightthickness=0
)


def show_page(page):

    for frame in (
        chat_page,
        announcements_page,
        users_page,
        bikking_page
    ):

        frame.pack_forget()

    page.pack(
        fill="both",
        expand=True
    )


def update_tab_buttons():

    for name, button in tab_buttons.items():

        if name == current_tab:

            button.configure(
                bg="#242424",
                activebackground="#242424"
            )

        else:

            button.configure(
                bg=BG,
                activebackground="#202020"
            )


def switch_tab(name):

    global current_tab

    if name == current_tab:
        return

    current_tab = name

    if name == "chat":

        show_page(
            chat_page
        )

    elif name == "announcements":

        show_page(
            announcements_page
        )

    elif name == "users":

        show_page(
            users_page
        )

    elif name == "bikking":

        show_page(
            bikking_page
        )

        load_bikking_assets()

        draw_bikking_world()

        start_bikking_animation()

    play_sound(
        os.path.join(
            BASE_DIR,
            "sounds",
            "tab_click.wav"
        )
    )

    update_tab_buttons()


tab_buttons = {}

chat_tab_button = tk.Button(
    titlebar,
    image=chat_tab_img,
    bg=BG,
    activebackground=BG,
    borderwidth=0,
    highlightthickness=0,
    relief="flat",
    command=lambda: switch_tab("chat")
)

chat_tab_button.place(
    x=437,
    y=4,
    width=32,
    height=32
)

tab_buttons["chat"] = chat_tab_button

announcements_tab_button = tk.Button(
    titlebar,
    image=announcements_tab_img,
    bg=BG,
    activebackground=BG,
    borderwidth=0,
    highlightthickness=0,
    relief="flat",
    command=lambda: switch_tab("announcements")
)

announcements_tab_button.place(
    x=469,
    y=4,
    width=32,
    height=32
)

tab_buttons["announcements"] = announcements_tab_button

users_tab_button = tk.Button(
    titlebar,
    image=users_locked_tab_img,
    bg=BG,
    activebackground=BG,
    borderwidth=0,
    highlightthickness=0,
    relief="flat",
    command=lambda: switch_tab("users")
)

users_tab_button.place(
    x=501,
    y=4,
    width=32,
    height=32
)

tab_buttons["users"] = users_tab_button

if bikking_tab_img is not None:

    bikking_tab_button = tk.Button(
        titlebar,
        image=bikking_tab_img,
        bg=BG,
        activebackground=BG,
        borderwidth=0,
        highlightthickness=0,
        relief="flat",
        command=lambda: switch_tab("bikking")
    )

else:

    bikking_tab_button = tk.Button(
        titlebar,
        text="🎣",
        bg=BG,
        fg=TEXT,
        activebackground=BG,
        activeforeground=TEXT,
        borderwidth=0,
        highlightthickness=0,
        relief="flat",
        font=("Segoe UI Emoji", 15),
        command=lambda: switch_tab("bikking")
    )

bikking_tab_button.place(
    x=533,
    y=4,
    width=32,
    height=32
)

tab_buttons["bikking"] = bikking_tab_button


emoji_images = {}


def load_emojis():

    os.makedirs(
        EMOJIS_DIR,
        exist_ok=True
    )

    for filename in os.listdir(
        EMOJIS_DIR
    ):

        path = os.path.join(
            EMOJIS_DIR,
            filename
        )

        if not os.path.isfile(path):
            continue

        name, extension = os.path.splitext(
            filename
        )

        if extension.lower() not in (
            ".png",
            ".jpg",
            ".jpeg",
            ".gif",
            ".webp"
        ):
            continue

        try:

            image = Image.open(
                path
            ).convert(
                "RGBA"
            )

            image = image.resize(
                (32, 32),
                Image.Resampling.LANCZOS
            )

            emoji_images[
                name.lower()
            ] = ImageTk.PhotoImage(
                image
            )

        except Exception:
            pass


load_emojis()


def insert_rich_content(
    widget,
    message,
    text_tag=None,
    link_enabled=True
):

    pattern_parts = []

    if link_enabled:

        pattern_parts.append(
            r"https://\S+"
        )

    pattern_parts.append(
        r":[A-Za-z0-9_-]+:"
    )

    pattern = re.compile(
        "(" +
        "|".join(pattern_parts) +
        ")"
    )

    parts = pattern.split(
        message
    )

    for part in parts:

        if not part:
            continue

        if (
            link_enabled
            and part.startswith("https://")
        ):

            start = widget.index(
                "end-1c"
            )

            widget.insert(
                "end",
                part,
                "link"
            )

            end = widget.index(
                "end-1c"
            )

            tag_name = (
                f"link_{start}"
            )

            widget.tag_add(
                tag_name,
                start,
                end
            )

            widget.tag_bind(
                tag_name,
                "<Button-1>",
                lambda event, url=part:
                webbrowser.open(url)
            )

            widget.tag_bind(
                tag_name,
                "<Enter>",
                lambda event:
                widget.config(
                    cursor="hand2"
                )
            )

            widget.tag_bind(
                tag_name,
                "<Leave>",
                lambda event:
                widget.config(
                    cursor=""
                )
            )

        elif (
            part.startswith(":")
            and part.endswith(":")
        ):

            emoji_name = part[
                1:-1
            ].lower()

            emoji = emoji_images.get(
                emoji_name
            )

            if emoji is not None:

                widget.image_create(
                    "end",
                    image=emoji,
                    align="center"
                )

            else:

                if text_tag:

                    widget.insert(
                        "end",
                        part,
                        text_tag
                    )

                else:

                    widget.insert(
                        "end",
                        part
                    )

        else:

            if text_tag:

                widget.insert(
                    "end",
                    part,
                    text_tag
                )

            else:

                widget.insert(
                    "end",
                    part
                )


def update_announcements_text(text):

    announcements_text.configure(
        state="normal"
    )

    announcements_text.delete(
        "1.0",
        "end"
    )

    insert_rich_content(
        announcements_text,
        text,
        "message",
        True
    )

    announcements_text.configure(
        state="disabled"
    )


top_frame = tk.Frame(
    chat_page,
    bg=BG
)

top_frame.pack(
    fill="x"
)

online_label = tk.Label(
    top_frame,
    text="0 online",
    bg=BG,
    fg=SYSTEM_TEXT,
    font=("Segoe UI", 9)
)

online_label.pack(
    side="left",
    padx=15
)

chat_frame = tk.Frame(
    chat_page,
    bg=CHAT_BG
)

chat_frame.pack(
    fill="both",
    expand=True,
    padx=10,
    pady=(0, 10)
)

chat_box = scrolledtext.ScrolledText(
    chat_frame,
    wrap="word",
    bg=CHAT_BG,
    fg=TEXT,
    insertbackground=TEXT,
    selectbackground="#444444",
    relief="flat",
    borderwidth=0,
    font=("Segoe UI", 10),
    state="disabled"
)

chat_box.pack(
    fill="both",
    expand=True
)

chat_box.tag_config(
    "time",
    foreground="#666666"
)

chat_box.tag_config(
    "username",
    foreground="#ffffff",
    font=("Segoe UI", 10, "bold")
)

chat_box.tag_config(
    "message",
    foreground=TEXT
)

chat_box.tag_config(
    "system",
    foreground=SYSTEM_TEXT,
    font=("Segoe UI", 9, "italic")
)

chat_box.tag_config(
    "link",
    foreground="#4da6ff",
    underline=True
)

input_frame = tk.Frame(
    chat_page,
    bg=BG,
    height=38
)

input_frame.pack(
    fill="x",
    padx=10,
    pady=(0, 10)
)

input_frame.pack_propagate(False)

message_entry = tk.Entry(
    input_frame,
    bg=INPUT_BG,
    fg=TEXT,
    insertbackground=TEXT,
    relief="flat",
    borderwidth=0,
    highlightthickness=0,
    font=("Segoe UI", 10)
)

message_entry.pack(
    side="left",
    fill="both",
    expand=True,
    padx=(0, 8)
)

attachment_button = tk.Button(
    input_frame,
    image=add_img,
    bg=BG,
    activebackground=BG,
    borderwidth=0,
    highlightthickness=0,
    relief="flat"
)

attachment_button.pack(
    side="right",
    fill="y",
    padx=(0, 4)
)

send_button = tk.Button(
    input_frame,
    image=send_img,
    bg=BG,
    activebackground=BG,
    borderwidth=0,
    highlightthickness=0,
    relief="flat"
)

send_button.pack(
    side="right",
    fill="y"
)

announcements_title = tk.Label(
    announcements_page,
    text="ANNOUNCEMENTS",
    bg=BG,
    fg=TEXT,
    font=("Segoe UI", 12, "bold")
)

announcements_title.pack(
    anchor="w",
    padx=15,
    pady=(15, 8)
)

announcements_text = tk.Text(
    announcements_page,
    wrap="word",
    bg=CHAT_BG,
    fg=TEXT,
    insertbackground=TEXT,
    selectbackground="#444444",
    relief="flat",
    borderwidth=0,
    font=("Segoe UI", 10),
    state="disabled"
)

announcements_text.pack(
    fill="both",
    expand=True,
    padx=10,
    pady=(0, 10)
)

announcements_text.tag_config(
    "message",
    foreground=TEXT
)

announcements_text.tag_config(
    "link",
    foreground="#4da6ff",
    underline=True
)

announcements_text.configure(
    state="normal"
)

announcements_text.insert(
    "end",
    "Announcements will be here.\n"
)

announcements_text.configure(
    state="disabled"
)

users_header = tk.Frame(
    users_page,
    bg=BG
)

users_header.pack(
    fill="x",
    padx=15,
    pady=(15, 8)
)

users_title = tk.Label(
    users_header,
    text="USERS",
    bg=BG,
    fg=TEXT,
    font=("Segoe UI", 12, "bold")
)

users_title.pack(
    side="left"
)

quote_button = tk.Button(
    users_header,
    text="Set Quote",
    bg=INPUT_BG,
    fg=TEXT,
    activebackground="#303030",
    activeforeground=TEXT,
    borderwidth=0,
    highlightthickness=0,
    relief="flat",
    font=("Segoe UI", 9),
    padx=10,
    pady=4
)

quote_button.pack(
    side="right"
)

users_frame = tk.Frame(
    users_page,
    bg=CHAT_BG
)

users_frame.pack(
    fill="both",
    expand=True,
    padx=10,
    pady=(0, 10)
)

users_text = scrolledtext.ScrolledText(
    users_frame,
    wrap="word",
    bg=CHAT_BG,
    fg=TEXT,
    insertbackground=TEXT,
    selectbackground="#303030",
    relief="flat",
    borderwidth=0,
    highlightthickness=0,
    font=("Segoe UI", 10),
    state="disabled"
)

users_text.pack(
    fill="both",
    expand=True,
    padx=8,
    pady=8
)

users_text.tag_config(
    "user",
    foreground=TEXT,
    font=("Segoe UI", 10, "bold")
)

users_text.tag_config(
    "quote",
    foreground=SYSTEM_TEXT,
    font=("Segoe UI", 9)
)

users_text.tag_config(
    "online_dot",
    foreground="#6fce68",
    font=("Segoe UI", 10, "bold")
)

users_text.tag_config(
    "user_link",
    foreground=TEXT
)


def update_users(users):

    global online_users

    online_users = list(
        users
    )

    users_text.configure(
        state="normal"
    )

    users_text.delete(
        "1.0",
        "end"
    )

    for index, user in enumerate(
        online_users
    ):

        if isinstance(
            user,
            dict
        ):

            name = str(
                user.get(
                    "username",
                    "Anonymous"
                )
            )

            quote = str(
                user.get(
                    "quote",
                    ""
                )
            )

            user_bikcoin = user.get(
                "bikcoin",
                0
            )

        else:

            name = str(
                user
            )

            quote = ""

            user_bikcoin = 0

        users_text.insert(
            "end",
            "● ",
            "online_dot"
        )

        users_text.insert(
            "end",
            f"{name} - BikCoin: {format_bikcoin(user_bikcoin)}",
            "user"
        )

        users_text.insert(
            "end",
            "\n"
        )

        if quote:

            users_text.insert(
                "end",
                "    "
            )

            insert_rich_content(
                users_text,
                quote,
                "quote",
                False
            )

            users_text.insert(
                "end",
                "\n"
            )

        if index < len(
            online_users
        ) - 1:

            users_text.insert(
                "end",
                "\n"
            )

    users_text.configure(
        state="disabled"
    )


def set_quote():

    if not running:
        return

    quote = simpledialog.askstring(
        "BikChat Quote",
        "Set your quote:",
        parent=root,
        initialvalue=""
    )

    if quote is None:
        return

    quote = quote.strip()

    if len(quote) > 100:

        add_system_message(
            "Quote is too long. Maximum 100 characters."
        )

        return

    try:

        send_packet(
            client,
            {
                "type": "set_quote",
                "quote": quote
            }
        )

    except OSError:

        add_system_message(
            "Could not update your quote."
        )


quote_button.configure(
    command=set_quote
)


def update_user_count(count):

    global user_count

    user_count = count

    online_label.configure(
        text=f"{count} online"
    )

    root.title(
        f"BikChat — {count} online"
    )


def load_username():

    try:

        with open(
            USERNAME_FILE,
            "r",
            encoding="utf-8"
        ) as file:

            username = file.read().strip()

        if username:
            return username

        return "Anonymous"

    except FileNotFoundError:

        username = "Anonymous"

        with open(
            USERNAME_FILE,
            "w",
            encoding="utf-8"
        ) as file:

            file.write(username)

        return username


username = load_username()


def play_join_sound():

    try:

        if random.randint(
            1,
            50
        ) == 1:

            play_sound(
                os.path.join(
                    BASE_DIR,
                    "sounds",
                    "joinRARE.wav"
                )
            )

        else:

            play_sound(
                os.path.join(
                    BASE_DIR,
                    "sounds",
                    "join.wav"
                )
            )

    except Exception:
        pass


def play_leave_sound():

    try:

        play_sound(
            os.path.join(
                BASE_DIR,
                "sounds",
                "leave.wav"
            )
        )

    except Exception:
        pass


def send_packet(sock, payload):

    data = json.dumps(
        payload,
        ensure_ascii=False
    ).encode(
        "utf-8"
    )

    packet = struct.pack(
        "!I",
        len(data)
    ) + data

    sock.sendall(
        packet
    )


def send_file_chunk(sock, data):

    packet = struct.pack(
        "!I",
        len(data)
    ) + data

    sock.sendall(
        packet
    )


def recv_packet(sock):

    header = recv_exact(
        sock,
        PACKET_HEADER_SIZE
    )

    if not header:
        return None

    size = struct.unpack(
        "!I",
        header
    )[0]

    if size > 64 * 1024:

        raise ValueError(
            "Packet too large."
        )

    data = recv_exact(
        sock,
        size
    )

    if data is None:
        return None

    return data


def recv_exact(sock, size):

    data = bytearray()

    while len(data) < size:

        chunk = sock.recv(
            size - len(data)
        )

        if not chunk:
            return None

        data.extend(
            chunk
        )

    return bytes(
        data
    )


def receive_json_packet(sock):

    data = recv_packet(
        sock
    )

    if data is None:
        return None

    if not data.startswith(
        b"{"
    ):

        raise ValueError(
            "Expected JSON packet."
        )

    return json.loads(
        data.decode(
            "utf-8"
        )
    )


def insert_message_content(message):

    insert_rich_content(
        chat_box,
        message,
        "message",
        True
    )


attachment_filenames = {}

attachment_buttons = {}

attachment_downloads = set()

attachment_download_lock = threading.Lock()


def attachment_hover_enter(event):

    try:

        event.widget.configure(
            cursor="hand2"
        )

    except Exception:
        pass


def attachment_hover_leave(event):

    try:

        event.widget.configure(
            cursor=""
        )

    except Exception:
        pass


def create_attachment_button(
    attachment_id,
    filename
):

    attachment_filenames[
        str(attachment_id)
    ] = filename

    button = tk.Button(
        chat_box,
        text=f"📎 {filename}",
        bg=CHAT_BG,
        fg="#8cc8ff",
        activebackground="#202020",
        activeforeground="#b8e0ff",
        borderwidth=0,
        highlightthickness=0,
        relief="flat",
        cursor="hand2",
        font=("Segoe UI", 10, "underline"),
        anchor="w",
        padx=0,
        pady=1,
        command=lambda aid=attachment_id:
        download_attachment(aid)
    )

    button.bind(
        "<Enter>",
        attachment_hover_enter
    )

    button.bind(
        "<Leave>",
        attachment_hover_leave
    )

    button.pack(
        anchor="w",
        fill="x"
    )

    attachment_buttons[
        str(attachment_id)
    ] = button

    chat_box.window_create(
        "end",
        window=button,
        align="baseline"
    )

    button.pack_forget()

    return button


def insert_attachment(
    attachment_id,
    filename
):

    attachment_id_string = str(
        attachment_id
    )

    attachment_filenames[
        attachment_id_string
    ] = filename

    button = tk.Button(
        chat_box,
        text=f"📎 {filename}",
        bg=CHAT_BG,
        fg="#8cc8ff",
        activebackground="#202020",
        activeforeground="#b8e0ff",
        borderwidth=0,
        highlightthickness=0,
        relief="flat",
        cursor="hand2",
        font=("Segoe UI", 10, "underline"),
        anchor="w",
        padx=4,
        pady=2,
        command=lambda aid=attachment_id:
        download_attachment(aid)
    )

    button.bind(
        "<Enter>",
        attachment_hover_enter
    )

    button.bind(
        "<Leave>",
        attachment_hover_leave
    )

    attachment_buttons[
        attachment_id_string
    ] = button

    chat_box.window_create(
        "end",
        window=button,
        align="baseline"
    )

    return button


def add_message(
    username,
    message,
    time_text=None,
    attachment_id=None,
    attachment_name=None
):

    if time_text is None:

        time_text = datetime.now().strftime(
            "%H:%M"
        )

    chat_box.configure(
        state="normal"
    )

    chat_box.insert(
        "end",
        f"[{time_text}] ",
        "time"
    )

    chat_box.insert(
        "end",
        f"{username}:",
        "username"
    )

    chat_box.insert(
        "end",
        "\n"
    )

    if message:

        insert_message_content(
            message
        )

    if attachment_id is not None:

        if message:

            chat_box.insert(
                "end",
                "\n"
            )

        insert_attachment(
            attachment_id,
            attachment_name or "Attachment"
        )

    chat_box.insert(
        "end",
        "\n\n"
    )

    chat_box.configure(
        state="disabled"
    )

    chat_box.see(
        "end"
    )


def add_system_message(message):

    time_text = datetime.now().strftime(
        "%H:%M"
    )

    chat_box.configure(
        state="normal"
    )

    chat_box.insert(
        "end",
        f"[{time_text}] • {message}\n\n",
        "system"
    )

    chat_box.configure(
        state="disabled"
    )

    chat_box.see(
        "end"
    )


def ensure_attachment_cache():

    os.makedirs(
        ATTACHMENT_CACHE_DIR,
        exist_ok=True
    )


def safe_cache_filename(
    attachment_id,
    filename
):

    filename = os.path.basename(
        filename
    )

    if not filename:

        filename = "attachment"

    return (
        f"{attachment_id}_{filename}"
    )


def get_cached_attachment_path(
    attachment_id,
    filename
):

    ensure_attachment_cache()

    return os.path.join(
        ATTACHMENT_CACHE_DIR,
        safe_cache_filename(
            attachment_id,
            filename
        )
    )


def open_cached_attachment(
    attachment_id,
    filename
):

    path = get_cached_attachment_path(
        attachment_id,
        filename
    )

    if not os.path.isfile(path):

        return False

    try:

        os.startfile(
            os.path.abspath(path)
        )

        return True

    except Exception as error:

        add_system_message(
            f"Could not open attachment: {error}"
        )

        return False


def download_attachment(
    attachment_id
):

    if not running:
        return

    if client is None:
        return

    attachment_key = str(
        attachment_id
    )

    filename = attachment_filenames.get(
        attachment_key,
        "attachment"
    )

    cached_path = get_cached_attachment_path(
        attachment_id,
        filename
    )

    if os.path.isfile(cached_path):

        if open_cached_attachment(
            attachment_id,
            filename
        ):

            return

    with attachment_download_lock:

        if attachment_key in attachment_downloads:

            return

        attachment_downloads.add(
            attachment_key
        )

    try:

        send_packet(
            client,
            {
                "type": "download_attachment",
                "id": attachment_id
            }
        )

        root.after(
            0,
            add_system_message,
            f"Downloading {filename}..."
        )

    except OSError:

        with attachment_download_lock:

            attachment_downloads.discard(
                attachment_key
            )

        root.after(
            0,
            add_system_message,
            "Could not request attachment."
        )


def finish_attachment_download(
    attachment_id
):

    with attachment_download_lock:

        attachment_downloads.discard(
            str(attachment_id)
        )


def receive_attachment_file(
    start_message
):

    attachment_id = start_message.get(
        "id"
    )

    filename = start_message.get(
        "filename",
        "attachment"
    )

    size = int(
        start_message.get(
            "size",
            0
        )
    )

    if attachment_id is None:

        raise ValueError(
            "Attachment ID missing."
        )

    if size < 0:

        raise ValueError(
            "Invalid attachment size."
        )

    attachment_key = str(
        attachment_id
    )

    attachment_filenames[
        attachment_key
    ] = filename

    ensure_attachment_cache()

    path = get_cached_attachment_path(
        attachment_id,
        filename
    )

    remaining = size

    with open(
        path,
        "wb"
    ) as file:

        while remaining > 0:

            chunk = recv_packet(
                client
            )

            if chunk is None:

                raise ConnectionError(
                    "Connection lost during attachment download."
                )

            if len(chunk) == 0:

                raise ValueError(
                    "Empty attachment packet."
                )

            if len(chunk) > remaining:

                raise ValueError(
                    "Invalid attachment data."
                )

            file.write(
                chunk
            )

            remaining -= len(
                chunk
            )

    end_packet = receive_json_packet(
        client
    )

    if (
        end_packet is None
        or end_packet.get("type") != "file_end"
    ):

        raise ValueError(
            "Attachment download did not finish correctly."
        )

    finish_attachment_download(
        attachment_id
    )

    root.after(
        0,
        add_system_message,
        f"Downloaded {filename}."
    )

    root.after(
        100,
        open_cached_attachment,
        attachment_id,
        filename
    )


def choose_attachment():

    if not running:
        return

    if client is None:
        return

    path = filedialog.askopenfilename(
        title="Choose an attachment"
    )

    if not path:
        return

    try:

        size = os.path.getsize(
            path
        )

    except OSError:

        add_system_message(
            "Could not read that file."
        )

        return

    filename = os.path.basename(
        path
    )

    mime_type = (
        mimetypes.guess_type(
            filename
        )[0]
        or "application/octet-stream"
    )

    threading.Thread(
        target=upload_attachment_thread,
        args=(
            path,
            filename,
            mime_type,
            size
        ),
        daemon=True
    ).start()


def upload_attachment_thread(
    path,
    filename,
    mime_type,
    size
):

    try:

        root.after(
            0,
            add_system_message,
            f"Uploading {filename}..."
        )

        send_packet(
            client,
            {
                "type": "upload_start",
                "filename": filename,
                "mime_type": mime_type,
                "size": size
            }
        )

        with open(
            path,
            "rb"
        ) as file:

            while True:

                chunk = file.read(
                    FILE_CHUNK_SIZE
                )

                if not chunk:
                    break

                send_file_chunk(
                    client,
                    chunk
                )

        send_packet(
            client,
            {
                "type": "upload_end"
            }
        )

    except Exception as error:

        root.after(
            0,
            add_system_message,
            f"Attachment upload failed: {error}"
        )


def clear_chat():

    chat_box.configure(
        state="normal"
    )

    chat_box.delete(
        "1.0",
        "end"
    )

    chat_box.configure(
        state="disabled"
    )

    for button in list(
        attachment_buttons.values()
    ):

        try:

            button.destroy()

        except Exception:
            pass

    attachment_buttons.clear()


client = None


def connect_to_server():

    global client

    while running:

        new_client = socket.socket(
            socket.AF_INET,
            socket.SOCK_STREAM
        )

        new_client.settimeout(
            5
        )

        try:

            new_client.connect(
                (
                    HOST,
                    PORT
                )
            )

            new_client.settimeout(
                None
            )

            client = new_client

            return True

        except (
            ConnectionRefusedError,
            socket.timeout,
            OSError
        ):

            try:
                new_client.close()
            except OSError:
                pass

            root.after(
                0,
                lambda:
                add_system_message(
                    "Server unavailable. Retrying..."
                )
            )

            time.sleep(
                RETRY_DELAY
            )

    return False


def send_message():

    global running

    if not running:
        return

    message = message_entry.get().strip()

    if not message:
        return

    if message.lower() == "/clear":

        message_entry.delete(
            0,
            "end"
        )

        clear_chat()

        return

    message_entry.delete(
        0,
        "end"
    )

    try:

        send_packet(
            client,
            {
                "type": "message",
                "message": message
            }
        )

    except OSError:

        add_system_message(
            "Connection lost."
        )

        running = False


send_button.configure(
    command=send_message
)

attachment_button.configure(
    command=choose_attachment
)

message_entry.bind(
    "<Return>",
    lambda event:
    send_message()
)


bikking_canvas = tk.Canvas(
    bikking_page,
    bg="#171b20",
    highlightthickness=0,
    borderwidth=0
)

bikking_canvas.pack(
    fill="both",
    expand=True,
    padx=10,
    pady=(10, 0)
)

bikking_bottom = tk.Frame(
    bikking_page,
    bg=BG,
    height=68
)

bikking_bottom.pack(
    fill="x",
    padx=10,
    pady=10
)

bikking_bottom.pack_propagate(False)

bikking_button = tk.Button(
    bikking_bottom,
    text="FISH FOR THINGS",
    bg="#303030",
    fg="#ffffff",
    activebackground="#505050",
    activeforeground="#ffffff",
    borderwidth=0,
    highlightthickness=0,
    relief="flat",
    font=("Segoe UI", 16, "bold"),
    padx=30,
    pady=8
)

bikking_button.pack(
    fill="both",
    expand=True
)

bikking_busy = False
bikking_bobber = None
bikking_line = None
bikking_water_offset = 0
bikking_bik_image = None
bikking_catch_images = {}
bikking_catch_photo_images = {}
bikking_catches = []

bikking_sky_image = None
bikking_water_image = None

bikking_sky_display_image = None
bikking_water_display_image = None

bikking_water_render_image = None

bikking_background_width = 0
bikking_background_sky_height = 0
bikking_background_water_height = 0

bikking_catch_name = None
bikking_catch_base_image = None
bikking_catch_display_image = None
bikking_catch_animation = False
bikking_catch_started = 0

bikking_assets_loaded = False
bikking_animation_job = None


def load_bikking_assets():

    global bikking_assets_loaded
    global bikking_bik_image
    global bikking_catch_images
    global bikking_catch_photo_images
    global bikking_catches
    global bikking_sky_image
    global bikking_water_image
    global bikking_sky_display_image
    global bikking_water_display_image
    global bikking_water_render_image
    global bikking_background_width
    global bikking_background_sky_height
    global bikking_background_water_height

    if bikking_assets_loaded:
        return

    os.makedirs(
        BIKKING_ASSETS_DIR,
        exist_ok=True
    )

    bikking_bik_image = None
    bikking_sky_image = None
    bikking_water_image = None

    bikking_sky_display_image = None
    bikking_water_display_image = None
    bikking_water_render_image = None

    bikking_background_width = 0
    bikking_background_sky_height = 0
    bikking_background_water_height = 0

    if os.path.isfile(
        BIKKING_BIK_PATH
    ):

        try:

            image = Image.open(
                BIKKING_BIK_PATH
            ).convert(
                "RGBA"
            )

            max_width = 220
            max_height = 160

            width, height = image.size

            scale = min(
                max_width / max(width, 1),
                max_height / max(height, 1),
                1
            )

            if scale != 1:

                image = image.resize(
                    (
                        max(
                            1,
                            int(width * scale)
                        ),
                        max(
                            1,
                            int(height * scale)
                        )
                    ),
                    Image.Resampling.LANCZOS
                )

            bikking_bik_image = ImageTk.PhotoImage(
                image
            )

        except Exception:

            bikking_bik_image = None

    if os.path.isfile(
        BIKKING_SKY_PATH
    ):

        try:

            bikking_sky_image = Image.open(
                BIKKING_SKY_PATH
            ).convert(
                "RGBA"
            )

        except Exception:

            bikking_sky_image = None

    if os.path.isfile(
        BIKKING_WATER_PATH
    ):

        try:

            bikking_water_image = Image.open(
                BIKKING_WATER_PATH
            ).convert(
                "RGBA"
            )

        except Exception:

            bikking_water_image = None

    catches = []

    try:

        filenames = os.listdir(
            BIKKING_ASSETS_DIR
        )

    except OSError:

        filenames = []

    for filename in filenames:

        path = os.path.join(
            BIKKING_ASSETS_DIR,
            filename
        )

        if not os.path.isfile(path):
            continue

        name, extension = os.path.splitext(
            filename
        )

        if extension.lower() != ".png":
            continue

        catches.append(
            (
                name,
                path
            )
        )

    catches.sort(
        key=lambda item: item[0].lower()
    )

    bikking_catches = catches

    bikking_catch_images.clear()
    bikking_catch_photo_images.clear()

    bikking_assets_loaded = True


def load_bikking_catch_image(name):

    if name in bikking_catch_images:

        return bikking_catch_images[name]

    for catch_name, path in bikking_catches:

        if catch_name != name:
            continue

        try:

            image = Image.open(
                path
            ).convert(
                "RGBA"
            )

            max_width = 150
            max_height = 120

            width, height = image.size

            scale = min(
                max_width / max(width, 1),
                max_height / max(height, 1),
                1
            )

            if scale != 1:

                image = image.resize(
                    (
                        max(
                            1,
                            int(width * scale)
                        ),
                        max(
                            1,
                            int(height * scale)
                        )
                    ),
                    Image.Resampling.LANCZOS
                )

            bikking_catch_images[
                name
            ] = image

            return image

        except Exception:

            return None

    return None


def get_bikking_catch_photo(name, image):

    if name in bikking_catch_photo_images:

        return bikking_catch_photo_images[name]

    if image is None:

        return None

    try:

        photo = ImageTk.PhotoImage(
            image
        )

        bikking_catch_photo_images[
            name
        ] = photo

        return photo

    except Exception:

        return None


def prepare_bikking_backgrounds(
    width,
    sky_height,
    water_height
):

    global bikking_sky_display_image
    global bikking_water_display_image
    global bikking_water_render_image
    global bikking_background_width
    global bikking_background_sky_height
    global bikking_background_water_height

    bikking_sky_display_image = None
    bikking_water_display_image = None
    bikking_water_render_image = None

    if (
        bikking_sky_image is not None
        and width > 0
        and sky_height > 0
    ):

        sky_source = bikking_sky_image

        sky_width, sky_source_height = sky_source.size

        if sky_width > 0 and sky_source_height > 0:

            scale = max(
                width / sky_width,
                sky_height / sky_source_height
            )

            new_width = max(
                width,
                int(sky_width * scale)
            )

            new_height = max(
                sky_height,
                int(sky_source_height * scale)
            )

            sky_resized = sky_source.resize(
                (
                    new_width,
                    new_height
                ),
                Image.Resampling.LANCZOS
            )

            crop_x = max(
                0,
                (new_width - width) // 2
            )

            crop_y = max(
                0,
                (new_height - sky_height) // 2
            )

            sky_crop = sky_resized.crop(
                (
                    crop_x,
                    crop_y,
                    crop_x + width,
                    crop_y + sky_height
                )
            )

            bikking_sky_display_image = ImageTk.PhotoImage(
                sky_crop
            )

    if (
        bikking_water_image is not None
        and width > 0
        and water_height > 0
    ):

        water_source = bikking_water_image

        water_width, water_source_height = water_source.size

        if water_width > 0 and water_source_height > 0:

            target_width = max(
                width * 1.5,
                width + 200
            )

            scale = max(
                target_width / water_width,
                water_height / water_source_height
            )

            new_width = max(
                int(water_width * scale),
                int(target_width)
            )

            new_height = max(
                water_height,
                int(water_source_height * scale)
            )

            water_resized = water_source.resize(
                (
                    new_width,
                    new_height
                ),
                Image.Resampling.LANCZOS
            )

            crop_y = max(
                0,
                (new_height - water_height) // 2
            )

            water_crop = water_resized.crop(
                (
                    0,
                    crop_y,
                    new_width,
                    crop_y + water_height
                )
            )

            bikking_water_render_image = water_crop

            bikking_water_display_image = ImageTk.PhotoImage(
                water_crop
            )

    bikking_background_width = width
    bikking_background_sky_height = sky_height
    bikking_background_water_height = water_height


def bikking_resize():

    if not bikking_page.winfo_ismapped():
        return

    draw_bikking_world()


def draw_bikking_world():

    global bikking_bobber
    global bikking_line
    global bikking_catch_display_image
    global bikking_sky_display_image
    global bikking_water_display_image
    global bikking_water_render_image

    if not bikking_page.winfo_ismapped():
        return

    if not bikking_assets_loaded:
        return

    width = bikking_canvas.winfo_width()
    height = bikking_canvas.winfo_height()

    if width < 10 or height < 10:
        return

    bikking_canvas.delete(
        "all"
    )

    sky_height = int(
        height * 0.42
    )

    water_height = (
        height - sky_height
    )

    if (
        bikking_background_width != width
        or bikking_background_sky_height != sky_height
        or bikking_background_water_height != water_height
    ):

        prepare_bikking_backgrounds(
            width,
            sky_height,
            water_height
        )

    if bikking_sky_display_image is not None:

        bikking_canvas.create_image(
            0,
            0,
            image=bikking_sky_display_image,
            anchor="nw",
            tags="bik_background"
        )

    else:

        bikking_canvas.create_rectangle(
            0,
            0,
            width,
            sky_height,
            fill="#1c2028",
            outline=""
        )

        bikking_canvas.create_oval(
            width - 100,
            35,
            width - 45,
            90,
            fill="#8a8a70",
            outline=""
        )

    if (
        bikking_water_display_image is not None
        and bikking_water_render_image is not None
    ):

        water_width = (
            bikking_water_render_image.width
        )

        max_offset = max(
            0,
            water_width - width
        )

        if max_offset > 0:

            cycle = max_offset * 2

            raw_offset = (
                bikking_water_offset
                % cycle
            )

            if raw_offset > max_offset:

                water_offset = (
                    cycle - raw_offset
                )

            else:

                water_offset = raw_offset

        else:

            water_offset = 0

        bikking_canvas.create_image(
            -water_offset,
            sky_height,
            image=bikking_water_display_image,
            anchor="nw",
            tags="bik_water"
        )

    else:

        bikking_canvas.create_rectangle(
            0,
            sky_height,
            width,
            height,
            fill="#164c67",
            outline=""
        )

    now = time.monotonic()

    boat_x = (
        width * 0.5
        + math.sin(
            now * 0.9
        ) * min(
            130,
            width * 0.18
        )
    )

    boat_y = (
        sky_height
        + 72
        + math.sin(
            now * 1.7
        ) * 4
    )

    if bikking_bik_image is not None:

        image_id = bikking_canvas.create_image(
            boat_x,
            boat_y,
            image=bikking_bik_image,
            anchor="center",
            tags="bik_world"
        )

        bikking_canvas.tag_bind(
            image_id,
            "<Button-1>",
            lambda event:
            bikking_cast()
        )

    else:

        bikking_canvas.create_oval(
            boat_x - 22,
            boat_y - 30,
            boat_x + 22,
            boat_y + 12,
            fill="#dddddd",
            outline=""
        )

        bikking_canvas.create_arc(
            boat_x - 65,
            boat_y - 2,
            boat_x + 65,
            boat_y + 38,
            start=180,
            extent=180,
            fill="#8a572e",
            outline="#5a351c",
            width=3
        )

        bikking_canvas.create_text(
            boat_x,
            boat_y - 8,
            text="BIK",
            fill="#111111",
            font=("Segoe UI", 9, "bold"),
            tags="bik_world"
        )

    if bikking_bobber is not None:

        bobber_x, bobber_y = bikking_bobber

        bikking_line = bikking_canvas.create_line(
            boat_x + 20,
            boat_y - 18,
            bobber_x,
            bobber_y,
            fill="#d7d7d7",
            width=2
        )

        bikking_canvas.create_oval(
            bobber_x - 5,
            bobber_y - 5,
            bobber_x + 5,
            bobber_y + 5,
            fill="#eeeeee",
            outline="#111111"
        )

    if bikking_catch_animation:

        draw_bikking_catch_overlay()


def draw_bikking_catch_overlay():

    global bikking_catch_display_image

    if not bikking_catch_animation:
        return

    width = bikking_canvas.winfo_width()
    height = bikking_canvas.winfo_height()

    if width < 10 or height < 10:
        return

    center_x = width * 0.5
    center_y = height * 0.46

    image = bikking_catch_base_image

    if image is not None:

        bikking_catch_display_image = get_bikking_catch_photo(
            bikking_catch_name,
            image
        )

        if bikking_catch_display_image is not None:

            bikking_canvas.create_image(
                center_x,
                center_y,
                image=bikking_catch_display_image,
                anchor="center",
                tags="catch_overlay"
            )

    title_y = center_y - 105

    bikking_canvas.create_text(
        center_x,
        title_y,
        text="Woah you caught a thingamajig",
        fill="#ffffff",
        font=(
            "Segoe UI",
            18,
            "bold"
        ),
        tags="catch_overlay"
    )

    name_text = bikking_catch_name or "???"

    bikking_canvas.create_text(
        center_x,
        center_y + 95,
        text=name_text,
        fill="#ffffff",
        font=(
            "Segoe UI",
            15,
            "bold"
        ),
        tags="catch_overlay"
    )


def bikking_animation_loop():

    global bikking_animation_job
    global bikking_water_offset

    bikking_animation_job = None

    if not running:
        return

    if not bikking_page.winfo_ismapped():
        return

    now = time.monotonic()

    if bikking_catch_animation:

        if (
            now - bikking_catch_started
            >= 2.7
        ):

            bikking_end_catch()

    bikking_water_offset += 2

    draw_bikking_world()

    if bikking_catch_animation:

        interval = 40

    else:

        interval = 60

    bikking_animation_job = root.after(
        interval,
        bikking_animation_loop
    )


def start_bikking_animation():

    global bikking_animation_job

    if not running:
        return

    if not bikking_page.winfo_ismapped():
        return

    if bikking_animation_job is not None:
        return

    bikking_animation_job = root.after(
        0,
        bikking_animation_loop
    )


def bikking_start_catch(name):

    global bikking_catch_name
    global bikking_catch_base_image
    global bikking_catch_display_image
    global bikking_catch_animation
    global bikking_catch_started

    bikking_catch_name = name

    bikking_catch_base_image = load_bikking_catch_image(
        name
    )

    bikking_catch_display_image = None

    bikking_catch_started = time.monotonic()

    bikking_catch_animation = True

    play_sound(
        os.path.join(
            BASE_DIR,
            "sounds",
            "tab_click.wav"
        )
    )

    if bikking_page.winfo_ismapped():

        draw_bikking_world()

        start_bikking_animation()


def bikking_end_catch():

    global bikking_busy
    global bikking_catch_animation
    global bikking_catch_name
    global bikking_catch_base_image
    global bikking_catch_display_image
    global bikking_bobber

    bikking_catch_animation = False

    bikking_catch_name = None

    bikking_catch_base_image = None

    bikking_catch_display_image = None

    bikking_bobber = None

    bikking_busy = False

    bikking_button.configure(
        state="normal",
        text="FISH FOR THINGS"
    )


def bikking_cast():

    global bikking_busy
    global bikking_bobber

    if not bikking_page.winfo_ismapped():
        return

    if bikking_busy:
        return

    if bikking_catch_animation:
        return

    bikking_busy = True

    bikking_button.configure(
        state="disabled",
        text="WAITING..."
    )

    width = bikking_canvas.winfo_width()
    height = bikking_canvas.winfo_height()

    if width < 10 or height < 10:

        bikking_busy = False

        bikking_button.configure(
            state="normal",
            text="FISH FOR THINGS"
        )

        return

    sky_height = int(
        height * 0.42
    )

    bobber_x = random.randint(
        max(60, int(width * 0.18)),
        min(width - 60, int(width * 0.82))
    )

    bobber_y = random.randint(
        sky_height + 45,
        height - 55
    )

    bikking_bobber = (
        bobber_x,
        bobber_y
    )

    draw_bikking_world()

    start_bikking_animation()

    delay = random.randint(
        1500,
        4200
    )

    root.after(
        delay,
        bikking_bite
    )


def bikking_bite():

    global bikking_busy
    global bikking_bobber

    if not running:
        return

    if not bikking_busy:
        return

    if not bikking_page.winfo_ismapped():

        bikking_busy = False
        bikking_bobber = None

        bikking_button.configure(
            state="normal",
            text="FISH FOR THINGS"
        )

        return

    if bikking_catches:

        name, path = random.choice(
            bikking_catches
        )

    else:

        default_catches = (
            "Fish",
            "Wet Sock",
            "Old Boot",
            "Absolutely Nothing"
        )

        name = random.choice(
            default_catches
        )

    bikking_bobber = None

    bikking_button.configure(
        state="disabled",
        text="FISH FOR THINGS"
    )

    bikking_start_catch(
        name
    )


def load_bikking_again():

    global bikking_assets_loaded

    bikking_assets_loaded = False

    load_bikking_assets()

    if bikking_page.winfo_ismapped():

        draw_bikking_world()

        start_bikking_animation()


bikking_canvas.bind(
    "<Configure>",
    lambda event:
    draw_bikking_world()
)

bikking_button.configure(
    command=bikking_cast
)


def receive_messages():

    global running
    global user_count

    try:

        while running:

            packet = recv_packet(
                client
            )

            if packet is None:

                running = False

                root.after(
                    0,
                    add_system_message,
                    "Disconnected from server."
                )

                break

            if packet.startswith(
                b"{"
            ):

                message = json.loads(
                    packet.decode(
                        "utf-8"
                    )
                )

                message_type = message.get(
                    "type"
                )

                if message_type == "history_start":

                    continue

                if message_type == "history_end":

                    continue

                if message_type == "history_message":

                    root.after(
                        0,
                        add_message,
                        message.get(
                            "username",
                            "Anonymous"
                        ),
                        message.get(
                            "message",
                            ""
                        ),
                        message.get(
                            "timestamp"
                        ),
                        message.get(
                            "attachment_id"
                        ),
                        message.get(
                            "attachment_name"
                        )
                    )

                    continue

                if message_type == "announcements":

                    root.after(
                        0,
                        update_announcements_text,
                        message.get(
                            "text",
                            ""
                        )
                    )

                    continue

                if message_type == "users":

                    root.after(
                        0,
                        update_users,
                        message.get(
                            "users",
                            []
                        )
                    )

                    continue

                if message_type == "user_count":

                    user_count = int(
                        message.get(
                            "count",
                            0
                        )
                    )

                    root.after(
                        0,
                        update_user_count,
                        user_count
                    )

                    continue

                if message_type == "join":

                    root.after(
                        0,
                        play_join_sound
                    )

                    root.after(
                        0,
                        add_system_message,
                        message.get(
                            "message",
                            ""
                        )
                    )

                    continue

                if message_type == "left":

                    root.after(
                        0,
                        play_leave_sound
                    )

                    root.after(
                        0,
                        add_system_message,
                        message.get(
                            "message",
                            ""
                        )
                    )

                    continue

                if message_type == "message":

                    root.after(
                        0,
                        add_message,
                        message.get(
                            "username",
                            "Anonymous"
                        ),
                        message.get(
                            "message",
                            ""
                        ),
                        message.get(
                            "timestamp"
                        ),
                        message.get(
                            "attachment_id"
                        ),
                        message.get(
                            "attachment_name"
                        )
                    )

                    continue

                if message_type == "upload_complete":

                    root.after(
                        0,
                        add_system_message,
                        f"Uploaded {message.get('filename', 'attachment')}."
                    )

                    continue

                if message_type == "error":

                    error_message = message.get(
                        "message",
                        "Server error."
                    )

                    attachment_id = message.get(
                        "id"
                    )

                    if attachment_id is not None:

                        finish_attachment_download(
                            attachment_id
                        )

                    root.after(
                        0,
                        add_system_message,
                        error_message
                    )

                    continue

                if message_type == "file_start":

                    receive_attachment_file(
                        message
                    )

                    continue

                if message_type == "file_end":

                    continue

    except ConnectionResetError:

        running = False

        root.after(
            0,
            add_system_message,
            "Connection lost."
        )

    except (
        OSError,
        ValueError,
        json.JSONDecodeError
    ) as error:

        if running:

            running = False

            root.after(
                0,
                add_system_message,
                f"Connection lost: {error}"
            )


def close_bikchat():

    global running

    running = False

    save_bikcoin()

    try:

        client.shutdown(
            socket.SHUT_RDWR
        )

    except (
        OSError,
        AttributeError
    ):
        pass

    try:

        client.close()

    except (
        OSError,
        AttributeError
    ):
        pass

    root.destroy()


def main():

    global client

    ensure_attachment_cache()

    show_page(
        chat_page
    )

    update_tab_buttons()

    update_bikcoin_display()

    root.after(
        60000,
        bikcoin_tick
    )

    add_system_message(
        f"You are: {username}"
    )

    add_system_message(
        "Connecting to BikChat..."
    )

    def connection_thread():

        global running

        if not connect_to_server():

            return

        try:

            send_packet(
                client,
                {
                    "type": "username",
                    "username": username
                }
            )

            send_packet(
                client,
                {
                    "type": "bikcoin_update",
                    "bikcoin": bikcoin
                }
            )

        except OSError:

            running = False

            root.after(
                0,
                add_system_message,
                "Failed to send username."
            )

            return

        root.after(
            0,
            add_system_message,
            "Connected to BikChat."
        )

        receiver = threading.Thread(
            target=receive_messages,
            daemon=True
        )

        receiver.start()

    threading.Thread(
        target=connection_thread,
        daemon=True
    ).start()

    message_entry.focus_set()

    root.after(
        100,
        check_console_focus
    )

    root.after(
        250,
        minimize_console
    )

    root.mainloop()


root.protocol(
    "WM_DELETE_WINDOW",
    close_bikchat
)

if __name__ == "__main__":

    main()